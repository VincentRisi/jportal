///
/// System : JPortal
/// $Source: /main/nedcor/cvsroot/dev/jportal/Connector.java,v $
/// $Author: vince $
/// $Date: 2002/03/13 11:52:30 $
/// $Revision: 1.2 $
///

package jportal;

import java.util.*;
import java.sql.*;

abstract public class Connector
{
  class Calendar extends GregorianCalendar
  {
    long AsMillis()
    {
      return getTimeInMillis();
    }
  }
  public Connection connection;
  abstract public String getUserstamp()              throws SQLException;
  public Timestamp getTimestamp()                    throws SQLException
  {
    Calendar now = new Calendar();
    return new Timestamp(now.AsMillis());
  }
  abstract public int getSequence(String table)      throws SQLException;
  public void setAutoCommit(boolean cond)            throws SQLException
  {
    connection.setAutoCommit(cond);
  }
  public void commit()                               throws SQLException
  {
    connection.commit();
  }
  public void rollback()                             throws SQLException
  {
    connection.rollback();
  }
}

