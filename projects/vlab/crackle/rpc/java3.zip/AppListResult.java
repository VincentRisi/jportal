/*
 * This code was generated, do not modify it here
 * modify it at source and regenerate it.
 * Mutilation, Spindlization and Bending will result in ...
 * Mutilation, Spindlization and Bending will result in ...
 */

package bbd.jinx.idl2;

import java.io.Serializable;
public class AppListResult implements Serializable
{
  public String[] list;
}
