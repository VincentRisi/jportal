/*
 * Created on Jan 23, 2004
 */
package bbd.jinx.server;
import java.sql.SQLException;

import bbd.idl2.rpc.SocketRpc;
import bbd.jinx.idl2.JinxAssign;
import bbd.jportal.ConnectorOracle;
/**
 * @author vince
 */
public class Handler extends Thread
{
  private Parcel parcel;
  private ConnectorOracle connector;
  private SocketRpc request;
  private JinxAssign assign;
  public Handler(
    Parcel parcel,
    String driverType,
    String server,
    String user,
    String password)
  {
    this.parcel = parcel;
    try
    {
      connector = new ConnectorOracle(driverType, server, user, password);
      assign = new JinxAssign(connector);
    }
    catch (SQLException e1)
    {
      e1.printStackTrace();
    }
		catch (Exception e2)
		{
			e2.printStackTrace();
		}
  }
  public void run()
  {
    while (true)
    {
      request = parcel.get();
      assign._process(request);
      request.close();
    }
  }
}
