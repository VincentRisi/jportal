/*
 * Created on Jan 23, 2004
 */
package bbd.jinx.server;
import bbd.idl2.rpc.IniReader;
/**
 * @author vince
 */
public class Server
{
  public static void main(String[] args)
  {
    try
    {
      IniReader ini = new IniReader(args[0]);
      String serverPort = ini.getString("Server", "port", "12345");
      int noHandlers = ini.getInteger("Server", "handlers", 4);
      String driverType = ini.getString("Database", "driverType", "oci8");
      String serverId = ini.getString("Database", "serverId", "dn29");
      String userId = ini.getString("Database", "userId", "npu");
      String password = ini.getString("Database", "password", "tiger");
      Parcel parcel = new Parcel();
      Listener listener = new Listener(parcel, serverPort);
      Handler[] handler = new Handler[noHandlers];
      listener.start();
      for (int i = 0; i < noHandlers; i++)
      {
        handler[i] =
          new Handler(parcel, driverType, serverId, userId, password);
        handler[i].start();
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}
