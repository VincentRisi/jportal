/*
 * This code was generated, do not modify it here
 * modify it at source and regenerate it.
 * Mutilation, Spindlization and Bending will result in ...
 * Mutilation, Spindlization and Bending will result in ...
 */

package bbd.jinx.idl2;

import java.io.Serializable;
import bbd.jinx.jportal.GrpsListStruct;
import bbd.jinx.jportal.GrpsList;
import java.sql.SQLException;

class _getGrpsListReturn implements Serializable
{
  public GrpsListResult _result;
  public _getGrpsListReturn()
  {
  }
  public _getGrpsListReturn(GrpsListResult _result)
  {
    this._result = _result;
  }
}
class _getAppListReturn implements Serializable
{
  public AppListResult _result;
  public _getAppListReturn()
  {
  }
  public _getAppListReturn(AppListResult _result)
  {
    this._result = _result;
  }
}
class _pingInput implements Serializable
{
  public int a;
  public _pingInput(int a)
  {
    this.a = a;
  }
}
class _pingReturn implements Serializable
{
  public int _result;
  public _pingReturn()
  {
  }
  public _pingReturn(int _result)
  {
    this._result = _result;
  }
}
public class JinxStructs
{
  private String version = "1.0.0.0";
  private int signature = 43078;
  public String getVersion() {return version;}
  public int getSignature() {return signature;}
  public static class Message
  { public static final int OK = 0
  , NotYetDone = 1000
  , INV_SIGNATURE = 1001
  , UNKNOWN_FUNCTION = 1002
  , LAST_LAST = 1003;
  }
  public static String messageDesc(int no)
  {
    switch (no)
    {
    case Message.OK: return "OK";
    case Message.NotYetDone: return "This has not yet been done.";
    case Message.INV_SIGNATURE: return "Invalid Signature";
    case Message.UNKNOWN_FUNCTION: return "Unknown Function";
    }
    return "MessageDesc for "+no+" Unknown.";
  }
}
