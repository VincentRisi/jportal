/*
 * This code was generated, do not modify it here
 * modify it at source and regenerate it.
 * Mutilation, Spindlization and Bending will result in ...
 * Mutilation, Spindlization and Bending will result in ...
 */

package bbd.jinx.idl2;

import bbd.idl2.rpc.Rpc;
import bbd.jinx.jportal.GrpsListStruct;
import bbd.jinx.jportal.GrpsList;
import java.sql.SQLException;

public class JinxProxy extends JinxStructs
{
  public Rpc _rpc;
  public GrpsListResult getGrpsList()
  {
    _getGrpsListReturn _rx = (_getGrpsListReturn) _rpc.call(1684986014, -2138589057);
    return _rx._result;
  }
  public AppListResult getAppList()
  {
    _getAppListReturn _rx = (_getAppListReturn) _rpc.call(242672169, -775063588);
    return _rx._result;
  }
  public int ping(int a)
  {
    _pingInput _tx = new _pingInput(a);
    _pingReturn _rx = (_pingReturn) _rpc.call(3441010, -3967753, _tx);
    return _rx._result;
  }
}
