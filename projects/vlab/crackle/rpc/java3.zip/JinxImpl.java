/*
 * This code was generated, do not modify it here
 * modify it at source and regenerate it.
 * Mutilation, Spindlization and Bending will result in ...
 * Mutilation, Spindlization and Bending will result in ...
 */

package bbd.jinx.idl2;

import bbd.jportal.Connector;
import bbd.jinx.jportal.GrpsListStruct;
import bbd.jinx.jportal.GrpsList;
import java.sql.SQLException;

public class JinxImpl extends JinxStructs
{
  private Connector connector;
  public JinxImpl(Connector connector)
  {
    this.connector = connector;
  }
  public GrpsListResult getGrpsList()
  {
    GrpsListResult result = new GrpsListResult();
    GrpsList grpsList = new GrpsList(connector);
    try
    {
      result.recs = grpsList.listLoad();
    }
    catch (SQLException e1)
    {
      e1.printStackTrace();
    } 
    return result;
  }
  public AppListResult getAppList()
  {
    AppListResult result = new AppListResult();
	result.list = new String[3];
	result.list[0] = "Groups";
	result.list[1] = "Staff";
	result.list[2] = "Scripts";
    return result;
  }
  public int ping(int a)
  {
    return a*a;
  }
}
