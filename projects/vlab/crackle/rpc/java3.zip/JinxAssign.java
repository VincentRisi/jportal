/*
 * This code was generated, do not modify it here
 * modify it at source and regenerate it.
 * Mutilation, Spindlization and Bending will result in ...
 * Mutilation, Spindlization and Bending will result in ...
 */

package bbd.jinx.idl2;

import bbd.idl2.rpc.Rpc;
import bbd.idl2.rpc.Header;
import bbd.jportal.Connector;
import bbd.jinx.jportal.GrpsListStruct;
import bbd.jinx.jportal.GrpsList;
import java.sql.SQLException;

public class JinxAssign extends JinxImpl
{
  public JinxAssign(Connector connector)
  {
    super(connector);
  }
  public void _process(Rpc rpc)
  {
    Header header = (Header)rpc.read();
    switch (header.message)
    {
    case 1684986014:
      if (header.signature != -2138589057)
      {
        header.returnCode = Message.INV_SIGNATURE;
        rpc.write(header);
        break;
      }
      _getGrpsListReturn tx0 = new _getGrpsListReturn();
      tx0._result = getGrpsList();
      header.returnCode = Message.OK;
      rpc.write(header);
      rpc.write(tx0);
      break;
    case 242672169:
      if (header.signature != -775063588)
      {
        header.returnCode = Message.INV_SIGNATURE;
        rpc.write(header);
        break;
      }
      _getAppListReturn tx1 = new _getAppListReturn();
      tx1._result = getAppList();
      header.returnCode = Message.OK;
      rpc.write(header);
      rpc.write(tx1);
      break;
    case 3441010:
      if (header.signature != -3967753)
      {
        header.returnCode = Message.INV_SIGNATURE;
        rpc.write(header);
        break;
      }
      _pingInput rx2 = (_pingInput)rpc.read();
      _pingReturn tx2 = new _pingReturn();
      tx2._result = ping(rx2.a);
      header.returnCode = Message.OK;
      rpc.write(header);
      rpc.write(tx2);
      break;
    default:
      header.returnCode = Message.UNKNOWN_FUNCTION;
      rpc.write(header);
      break;
    }
  }
}
